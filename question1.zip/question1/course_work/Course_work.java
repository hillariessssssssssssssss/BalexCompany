/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vu.course_work;

/**
 *
 * @author HILARY UGO453
 */
public class Course_work {
    public static void main(String[] args) {
        //intialise the objects
    balexCompany emp1,emp2,emp3;
    // invoke the methods and declare the objects
    System.out.println("EMPLOYERE 1 TOTAL PAY");
       emp1 = new balexCompany(7.5,35);        
       emp1.paydetails();
    System.out.println("EMPLOYERE 2 TOTAL PAY");
       emp2 = new balexCompany(8.20,47);
       emp2.paydetails();
    System.out.println("EMPLOYERE 3 TOTAL PAY");
       emp3 = new balexCompany(10.00,73);
       emp3.paydetails();
    }
}
